/****************************************************************/
/* Portfolio Selection Algorithm:                               */
/* Ref: Financial Policy Decisions in EURACE, (June 6, 2007)    */
/*      Portfolio Selection Algorithm, Section 6.3, pp. 17--18. */
/* Sander van der Hoog, 7/6/2007                                */
/****************************************************************/
#include <header.h>

#define HISTLENGTH 60                     /* HISTLENGTH: history length of performance of asset allocation rules */
#define EmptyAssetPortfolio  {DEFINITION} /* Add definition of an empty asset portfolio data structure */
#define DAILYRULES 10
/*********************************
 * household
 * asset market role
 **********************************/
 
/*As FA agent uses this function it could be made as a global function, if you dont want it to be used as one particular agents function*/ 
void update_rule_performance(rule_database, current_rule_number, rule_performance, rule_asset_value);
{
    RuleDatabaseType   rule_database=get_rule_database();
    double[HISTLENGTH] tmparray;
 
   /* Update the most recent asset value invested using this rule: */
    rule_database[current_rule_number].rule_asset_value = rule_asset_value;
 
   /* Update the performance history of the rule: */
    rule_database[current_rule_number].performance_history[1] = rule_performance;
    for (i=2; i<HISTLENGTH; i++)
    {  
        tmparray = rule_database[current_rule_number].performance_history;
        rule_database[current_rule_number].performance_history[i] = tmparray[i+1];
 
    }
    set_rule_database(rule_database);
}
 
 // household function
 int HouseholdPortfolioSelectionAlgorithm1()
{
/* Get input vars: declare and assign local vars */
    int                 household_id = get_household_id();
    double              asset_budget = get_asset_budget();
    int                 current_rule_number      = get_current_rule_number();
    double              current_rule_performance = get_current_rule_performance;
    AssetPortfolioType  current_assetportfolio   = get_current_assetportfolio();
    AssetPortfolioType  target_asset_portfolio   = EmptyAssetPortfolio;
    
/* STEP 1. Updating performance.
 * HERE: Household sends message to FA agent with the average per-day performance of it's current rule,
 * including also the total value invested in the asset portfolio (this is needed later on, when another household
 * uses this rule).
 */
 
    rule_performance = calc_rule_performance(current_assetportfolio.performance_history);
    add_rule_performance_message(household_id, current_rule_number, rule_performance, rule_asset_value, range, x, y, z);
    return 0;
}

//financial agent function
int FinancialAgent_reads()
{
  rule_performance_message = get_first_rule_performance_message()
  while(rule_performance_message)
  {
     household_id = rule_performance_message->household_id;
     current_rule_number = rule_performance_message->current_rule_number;
     rule_performance = rule_performance_message->rule_performance;
     rule_asset_value = rule_performance_message->rule_asset_value;
 
    /* Update rule performance: */ //calls function defined on top
     update_rule_performance(rule_database, current_rule_number, rule_performance, rule_asset_value);
  
     rule_performance_message = get_next_rule_performance_message(rule_performance_message)
   }
   /* This message is send after ALL household may have send an update,
    * and it can be read by ALL household agents: 
    */
   add_all_rule_performances_message(rule_performances, range, x, y, z);

   return 0;
}

//household function2
//reads all messages from the FA agent
int Household_reads_rule_performances_messages()
{
    all_rule_performances_message = get_first_all_rule_performances_message()
    while(all_rule_performances_message)
    {
    /* Read the message: */
    rule_performances = all_rule_performances_message->rule_performances;

    /* Store in memory: */
    set_rule_performances(rule_performances);

    /* Proceed to next message: */
    all_rule_performances_message = get_next_all_rule_performances_message(all_rule_performances_message)
    }
    
    // household can select allocation rule at the end of this function
    selected_rule_number=select_allocation_rule(rule_performances);

    set_selected_rule_number(selected_rule_number);
    
    // household can also request the info it needs here instead of in a separate function
    add_rule_details_request_message(household_id, selected_rule_number, range, x, y, z);
    
    return 0;
}

int FinancialAgent_sends_requested_message()
{
    //get_first_rule_details_request_message
    //enter while loop
    //check for household_id, get rule request
    //if found add rule requested message and drop out of while loop by making the message null
    
    return 0;
}

int Household_readsassetportfoliomessage()
{
    rule_details_message = get_first_rule_details_message()
    while(rule_details_message)
    {
       /* Test id: We only want the message that is personally directed to the household */
        if(household_id == rule_details_request_message->household_id)
        {
            prescribed_assetportfolio = rule_details_message->rule_database[selected_rule_number].assetportfolio;
        }
       rule_details_message = get_next_rule_details_request_message(rule_details_request_message) 
    }
}

// then the firm agent comes in. so that would incoporate seperate functions for the firm agents reading messages


    
